
<html>
<form method="POST" action="index.php#encrypt">
  <p></p><table>
    <tbody><tr><td align="right">Key:</td><td><input type="text" name="key" value="abcdefghijuklmno0123456789012345" size="34"></td></tr>
    <tr><td align="right">Mode:</td><td><select name="mode" style="width: 120px"><option value="ECB">ECB</option><option value="CBC" selected="">CBC</option><option value="CFB">CFB</option><option value="OFB">OFB</option></select></td></tr>
    <tr><td align="right">Initialization Vector:</td><td><input type="text" name="iv" value="1234567890abcdef" size="16"> (used in all modes except ECB)</td></tr>
    <tr><td align="right" valign="top">Plain-Text:</td><td><textarea name="plaintext" cols="40" rows="5">hello world!</textarea></td></tr>
    <tr><td></td><td><input type="submit" name="submit" value="Encrypt!"></td></tr>
  </tbody></table>
  </form>
</html>

<?php print("-- Start --<br />");
include("Aes_old.php");
$z = $_POST['key'];
$data = $_POST['plaintext'];
$mode = $_POST['mode'];
$iv = $_POST['iv'];

$aes = new AES($z, $mode, $iv);
$starte = microtime(true);
$encrypted = $aes->encrypt($data);
$ende = microtime(true);
print "Execution time to encrypt: " . ($ende - $starte) . " seconds<br />";
print "Cipher-Text: " . $encrypted . "<br />";
print "Hex: " . bin2hex($encrypted) . "<br />";
print "Base 64: " . base64_encode($encrypted) . "<br /><br />";
$startd = microtime(true);
$decrypted = $aes->decrypt($encrypted);
$endd = microtime(true);
print "Execution time to decrypt: " . ($endd - $startd) . " seconds<br />";
print "Decrypted-Text: " . stripslashes($decrypted);
print "<br />-- End --<br />";
?>