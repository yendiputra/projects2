<?php
//include "function_token.php";


?>
<html>
<!--form method="POST" action="">
  <p></p><table>
    <tbody><tr><td align="right">Key:</td><td><input type="text" name="key" value="abcdefghijuklmno0123456789012345" size="34"></td></tr>
    <tr><td align="right">Mode:</td><td><select name="mode" style="width: 120px"><option value="CBC">CBC</option><option value="CBC" selected="">CBC</option><option value="CFB">CFB</option><option value="OFB">OFB</option></select></td></tr>
    <tr><td align="right">Initialization Vector:</td><td><input type="text" name="iv" value="1234567890abcdef" size="16"> (used in all modes except ECB)</td></tr>
    <tr><td align="right" valign="top">Plain-Text:</td><td><textarea name="plaintext" cols="40" rows="5">hello world!</textarea></td></tr>
    <tr><td></td><td><input type="submit" name="submit" value="Encrypt!"></td></tr>
  </tbody></table>
  </form-->
  
<html>
<head>
<title>File Belajar cara mengatasi XSS</title>
</head>
<body>
<h1>Belajar cara mengatasi XSS. </h1>
<form action="" method="GET">
<input type="text" name="q" value="" />
<input type="submit" value="Search" />
</form>
</html>

<?php
/*if (isset($_GET['q'])) echo 'Anda mencari : '. $_GET['q'];


if( array_key_exists( "q", $_GET ) && $_GET[ 'q' ] != NULL ) {
	// Get input
	$q = preg_replace( '/<(.*)s(.*)c(.*)r(.*)i(.*)p(.*)t/i', '', $_GET[ 'q' ] );

	// Feedback for end user
	echo "<pre>Hello ${q}</pre>";
	//echo 'anda mencari'.${q};
}
*/
//if( array_key_exists( "q", $_GET ) && $_GET[ 'q' ] != NULL ) {
	// Check Anti-CSRF token
	//checkToken( $_REQUEST[ 'user_token' ], $_SESSION[ 'session_token' ], 'index.php' );

	// Get input
	//$q = htmlspecialchars( $_GET[ 'q' ] );

	// Feedback for end user
	//$html .= "<pre>Hello ${q}</pre>";
	//echo "<pre>Hello ${q}</pre>";
	
//}


// Generate Anti-CSRF token
//generateSessionToken();

?>
<br><br>
Ikuti tutorial lengkapnya di <a href="https://www.enmicronlab" Enmicron lab</a>
</body>
</html>	