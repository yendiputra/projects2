<?php
session_start();
include "set.php";

// Token functions --
function checkToken( $user_token, $session_token, $returnURL ) {  # Validate the given (CSRF) token
	if( $user_token !== $session_token || !isset( $session_token ) ) {
		dvwaMessagePush( 'CSRF token is incorrect' );
		dvwaRedirect( $returnURL );
	}
}

function generateSessionToken() {  # Generate a brand new (CSRF) token
	if( isset( $_SESSION[ 'session_token' ] ) ) {
		destroySessionToken();
	}	
		// Proses encrypt plaintext dari md5 uniqid
		include("Aes.php");
		$z = 'abcdefghijuklmno0123456789012345';
		$data = md5( uniqid() );
		$mode = 'cbc';
		$iv = '1234567890abcdef';

		/*$z = $_POST['key'];
		$data = $_POST['plaintext'];
		$mode = $_POST['mode'];
		$iv = $_POST['iv'];*/

		$aes = new AES($z, $mode, $iv);
		$starte = microtime(true);
		$encrypted = $aes->encrypt($data);
		$ende = microtime(true);
		print "Execution time to encrypt: " . ($ende - $starte) . " seconds<br />";
		print "Cipher-Text: " . $encrypted . "<br />";
		print "Hex: " . bin2hex($encrypted) . "<br />";
		print "Base 64: " . base64_encode($encrypted) . "<br /><br />";
		$startd = microtime(true);

		$decrypted = $aes->decrypt($encrypted);
		$endd = microtime(true);
		print "Execution time to decrypt: " . ($endd - $startd) . " seconds<br />";
		print "Decrypted-Text: " . stripslashes($decrypted);
		print "<br />-- End --<br />";	
	
	$_SESSION[ 'session_token' ] = $encrypted;
	//echo $encrypted."<br>";
	//echo "ini bagian dekrip".$decrypted;
}

function destroySessionToken() {  # Destroy any session with the name 'session_token'
	unset( $_SESSION[ 'session_token' ] );
}

function tokenField() {  # Return a field for the (CSRF) token
	return "<input type='hidden' name='user_token' value='{$_SESSION[ 'session_token' ]}' />";
}
// -- END (Token functions)
?>