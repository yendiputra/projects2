<?php
include "function_token.php";
?>
<html>
<head>
<title>File Belajar cara mengatasi XSS</title>
</head>
<body>
<h1>Belajar cara mengatasi XSS. </h1>
<form action="" method="GET">
<input type="text" name="q" value="" />
<input type="text" name="y" value="" />
<input type="submit" value="Search" />
</form>
<?php

// Is there any input?
//if (isset($_GET['q'])) echo 'Anda mencari : '. $_GET['q'];
//if (isset($_GET['y'])) echo 'Anda mencari : '. $_GET['y'];
if( array_key_exists( "q", $_GET ) && $_GET[ 'q' ] != NULL ) {
	// Check Anti-CSRF token
	checkToken( $_REQUEST[ 'user_token' ], $_SESSION[ 'session_token' ], 'cek.php' );

	// Get input
	$q = htmlspecialchars( $_GET[ 'q' ] );
	$y = htmlspecialchars( $_GET[ 'y' ] );
	//$q = str_replace( '<script>', '', $_GET[ 'q' ] );

	// Feedback for end user
	echo "<pre>Hello ${q}</pre>";
	echo "<pre>Hello ${y}</pre>";
}

// Generate Anti-CSRF token
generateSessionToken();


?>
