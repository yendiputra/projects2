<html>
<head>
<title>File Belajar cara mengatasi XSS</title>
</head>
<body>
<h1>Belajar cara mengatasi XSS. </h1>
<form action="" method="GET">
<input type="text" name="q" value="" />
<input type="submit" value="Search" />
</form>
<?php
if (isset($_GET['q'])) echo 'Anda mencari : '. $_GET['q'];


/*if( array_key_exists( "q", $_GET ) && $_GET[ 'q' ] != NULL ) {
	// Get input
	$q = preg_replace( '/<(.*)s(.*)c(.*)r(.*)i(.*)p(.*)t/i', '', $_GET[ 'q' ] );

	// Feedback for end user
	echo "<pre>Hello ${q}</pre>";
	//echo 'anda mencari'.${q};
}
if( array_key_exists( "q", $_GET ) && $_GET[ 'q' ] != NULL ) {
	// Check Anti-CSRF token
	checkToken( $_REQUEST[ 'user_token' ], $_SESSION[ 'session_token' ], 'index.php' );

	// Get input
	$q = htmlspecialchars( $_GET[ 'q' ] );

	// Feedback for end user
	$html .= "<pre>Hello ${q}</pre>";
}


// Generate Anti-CSRF token
generateSessionToken();*/


//creates a unique id with the 'about' prefix

/*langkah-langkah engkripsi dengan aes 256 cbc dan md5
1. data token di ambil secara acak mengudanan fungsi md5(uniqid())
2. data yang telah dapat di enkripi mengunakan aes 256 cbc agar token tidak mudah ditebak
 */



$ab="6bf9cdd6e7b2f55ee20d4c9adc913b6e";
$z="[�]���������]�2i?1�O/f�x���1�";
echo $z;
$enkri="123+". md5 (uniqid());
$a = md5( uniqid());
echo $a."<br>";
echo $enkri;
echo "<br>";
$b = uniqid (about, true);
echo $b;
echo "<br>";
$c = uniqid (rand(), true);
echo $c;
echo "<br>";
$md5c = md5($c);
echo $md5c."<br>";

$md5ambil="admj78in";
$enkripmd5=md5($md5ambil);
echo $enkripmd5;
echo "<br>";
?>


<br><br>
Ikuti tutorial lengkapnya di <a href="https://www.ethic.ninja/">Ethic Ninja</a>
</body>
</html>	