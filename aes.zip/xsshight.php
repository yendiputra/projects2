<html>
<head>
<title>File Belajar cara mengatasi XSS</title>
</head>
<body>
<h1>Belajar cara mengatasi XSS. </h1>
<form action="" method="GET">
<input type="text" name="q" value="" />
<input type="submit" value="Search" />
</form>
<?php
if (isset($_GET['q'])) echo 'Anda mencari : '. $_GET['q'];


// Is there any input?
if( array_key_exists( "q", $_GET ) && $_GET[ 'q' ] != NULL ) {
	// Get input
	$q = preg_replace( '/<(.*)s(.*)c(.*)r(.*)i(.*)p(.*)t/i', '', $_GET[ 'q' ] );

	// Feedback for end user
	echo "<pre>Hello ${q}</pre>";
}

?>