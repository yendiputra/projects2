<?php
// Token functions --
function checkToken( $user_token, $session_token, $returnURL ) {  # Validate the given (CSRF) token
	if( $user_token !== $session_token || !isset( $session_token ) ) {
		dvwaMessagePush( 'CSRF token is incorrect' );
		dvwaRedirect( $returnURL );
	}
}

function generateSessionToken() {  # Generate a brand new (CSRF) token
	if( isset( $_SESSION[ 'session_token' ] ) ) {
		destroySessionToken();
	}
	$_SESSION[ 'session_token' ] = md5( uniqid() );
}

function destroySessionToken() {  # Destroy any session with the name 'session_token'
	unset( $_SESSION[ 'session_token' ] );
}

function tokenField() {  # Return a field for the (CSRF) token
	return "<input type='hidden' name='user_token' value='{$_SESSION[ 'session_token' ]}' />";
}
// -- END (Token functions)
?>

<html>
<head>
<title>File Belajar cara mengatasi XSS</title>
</head>
<body>
<h1>Belajar cara mengatasi XSS. </h1>
<form action="" method="GET">
<input type="text" name="q" value="" />
<input type="submit" value="Search" />
</form>
<?php
/*if (isset($_GET['q'])) echo 'Anda mencari : '. $_GET['q'];


if( array_key_exists( "q", $_GET ) && $_GET[ 'q' ] != NULL ) {
	// Get input
	$q = preg_replace( '/<(.*)s(.*)c(.*)r(.*)i(.*)p(.*)t/i', '', $_GET[ 'q' ] );

	// Feedback for end user
	echo "<pre>Hello ${q}</pre>";
	//echo 'anda mencari'.${q};
}
*/
if( array_key_exists( "q", $_GET ) && $_GET[ 'q' ] != NULL ) {
	// Check Anti-CSRF token
	//checkToken( $_REQUEST[ 'user_token' ], $_SESSION[ 'session_token' ], 'index.php' );

	// Get input
	//$q = htmlspecialchars( $_GET[ 'q' ] );

	// Feedback for end user
	//$html .= "<pre>Hello ${q}</pre>";
	echo "<pre>Hello ${q}</pre>";
}


// Generate Anti-CSRF token
generateSessionToken();

?>
<br><br>
Ikuti tutorial lengkapnya di <a href="https://www.enmicronlab" Enmicron lab</a>
</body>
</html>	