BLOGBUGABAGI
=======================================
https://blogbugabagi.blogspot.com
IG	: instagram.com/blogbugabagi
FB	: facebook.com/bugabagiblog
=======================================
PASSWORD : blogbugabagi.blogspot.com
=======================================
Terima kasih :) :) 
=======================================
------:::::***** CREDIT *****:::::-----

=======================================

====---//INSTALASI SOURCE CODE\\---====

-Ekstrak source code-nya
-Copy ke localhost / host
-jika pakai xampp copy ke folder htdocs
-buat database baru di phpmyadmin
-import file sql ke database baru tadi

====---//INSTALASI SOURCE CODE\\---====
Administrator
username    : admin
password    : admin

User
username    : user
password    : user

=====-----/////FAQ ERROR\\\\\-----=====

??. Unknown database ''
!!. Database belum dibuat atau nama database sama
>>. Buat database baru atau perbaiki nama database

??. Access denied for user ''
!!. username atau password akun phpmyadmin tidak sesuai
>>. sesuaikan koneksi database dengan akun phpmyadmin

??. Uncaught Error: Call to undefined function mysql_connect()
!!. fungsi mysql tidak tersedia atau sudah tidak di dukung
>>. Gunakan versi PHP5 atau versi xampp yang lawas (jadul)

??. mysqli::real_connect(): / Warning: mysqli_connect():
!!. fungsi mysqli tidak tersedia atau tidak di dukung
>>. Gunakan versi PHP7 ke atas atau versi Xampp terbaru

??. Style tampilan antarmuka acak-acakan (tidak rapih)
!!. file css / style tidak ditemukan atau belum responsif
>>. Gunakan internet saat menjalankan-nya atau sesuaikan ukuran tampilan

#NOTE:
Berberapa masalah dan solusi penanganan di atas mungkin saja tidak dapat
menyelesaikan masalah dikarenakan beberapa faktor lain atau solusi lain.